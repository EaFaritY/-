# ระบบรางวัลกีฬาสี — แยกเป็น 2 เว็บ

| โฟลเดอร์ | หน้าที่ | พอร์ตแนะนำ |
|---|---|---|
| `public-web/` | เว็บผู้ใช้ทั่วไป: ค้นหาผล, ดู/ดาวน์โหลดใบเกียรติบัตร, `/api/search` | 3000 |
| `admin-web/` | เว็บแอดมิน (`/admin`): login, จัดการการแข่งขัน/นักเรียน/ผลรางวัล, อัปโหลดใบเกียรติบัตร, **เป็นเจ้าของ migration + seed** | 3001 |

## ข้อมูลที่ใช้ร่วมกัน (ไม่ได้คุยกันผ่าน API)
```
admin-web --เขียน--> PostgreSQL <--อ่าน-- public-web
admin-web --บันทึกไฟล์--> shared-uploads/certificates <--อ่าน-- public-web
public-web --INSERT--> search_logs --อ่าน--> dashboard ของ admin-web
```
1. **ฐานข้อมูลเดียวกัน** ตั้ง `DATABASE_URL` ชี้ DB เดียว. เว็บผู้ใช้ควรใช้ role read-only (`admin-web/db/public-readonly-role.sql`)
2. **โฟลเดอร์ไฟล์เกียรติบัตรเดียวกัน** ตั้ง `CERTIFICATE_UPLOAD_DIR` ในทั้งสองเว็บให้ชี้ path เดียวกัน (ใช้ absolute path). ทั้งสองเว็บเสิร์ฟ `/uploads/certificates/<file>.jpg` จากโฟลเดอร์นี้. ถ้า deploy คนละเครื่อง ให้ย้ายไป S3/R2 โดยแก้ `admin-web/src/lib/storage.ts` และ route `uploads`
3. `schema.ts` มี 2 สำเนา (`admin-web/src/db/schema.ts` เป็นต้นฉบับ). **แก้ schema ที่ admin-web แล้วคัดลอกไป public-web เสมอ**

## เริ่มต้น
```bash
# 1) admin-web (ทำ migration + seed ข้อมูลตัวอย่าง)
cd admin-web && cp .env.example .env && npm install
npm run db:migrate && npm run db:seed
psql "$DATABASE_URL" -f db/public-readonly-role.sql   # สร้าง role ให้เว็บผู้ใช้ (รันด้วย superuser)
npm run dev -- -p 3001      # แอดมินเริ่มต้น: admin / admin2569 (เปลี่ยนก่อนใช้จริง)

# 2) public-web
cd ../public-web && cp .env.example .env && npm install
npm run dev -- -p 3000
```
ตั้ง `NEXT_PUBLIC_PUBLIC_SITE_URL=http://localhost:3000` ใน admin-web เพื่อให้ปุ่ม "ดู" ใบเกียรติบัตรชี้ไปเว็บผู้ใช้
